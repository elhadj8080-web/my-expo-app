import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
export default function TopBar({ title, onBack }){
  return (
    <View style={{padding:16, backgroundColor:'#2e7d32', flexDirection:'row', alignItems:'center'}}>
      {onBack ? <TouchableOpacity onPress={onBack} style={{marginRight:8}}><Text style={{color:'#fff', fontSize:18}}>⬅︎</Text></TouchableOpacity> : null}
      <Text style={{color:'#fff', fontSize:18, fontWeight:'700'}}>{title}</Text>
    </View>
  );
}
