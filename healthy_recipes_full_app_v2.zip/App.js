import * as React from 'react';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Home from './screens/Home';
import Category from './screens/Category';
import Search from './screens/Search';
import Details from './screens/Details';
import Favs from './screens/Favs';
import Shop from './screens/Shop';
import Add from './screens/Add';
import AI from './screens/AI';
import TopBar from './components/TopBar';
import { Ionicons } from '@expo/vector-icons';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function Tabs(){
  return (
    <Tab.Navigator screenOptions={({route})=>({
      headerShown:false,
      tabBarActiveTintColor:'#2e7d32',
      tabBarIcon:({color,size})=>{
        const map={Home:'home',Favs:'heart',Shop:'cart',Add:'add-circle',AI:'sparkles'};
        const nm = map[route.name] || 'ellipse';
        return <Ionicons name={nm} size={size} color={color}/>;
      }
    })}>
      <Tab.Screen name="Home" component={Home} options={{title:'الرئيسية'}}/>
      <Tab.Screen name="Favs" component={Favs} options={{title:'المفضلة'}}/>
      <Tab.Screen name="Shop" component={Shop} options={{title:'التسوّق'}}/>
      <Tab.Screen name="Add" component={Add} options={{title:'أضف وصفة'}}/>
      <Tab.Screen name="AI" component={AI} options={{title:'مساعد'}}/>
    </Tab.Navigator>
  );
}

export default function App(){
  return (
    <NavigationContainer theme={{...DefaultTheme, colors:{...DefaultTheme.colors, background:'#fff'}}}>
      <Stack.Navigator screenOptions={{headerShown:false}}>
        <Stack.Screen name="Tabs" component={Tabs}/>
        <Stack.Screen name="Category" component={Category}/>
        <Stack.Screen name="Search" component={Search}/>
        <Stack.Screen name="Details" component={Details}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
