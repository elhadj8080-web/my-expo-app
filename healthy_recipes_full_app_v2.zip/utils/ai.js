// utils/ai.js - offline lightweight recipe suggester
export function suggestRecipeByGoal(goal, pantry) {
  const g = (goal||'').toLowerCase();
  const p = (pantry||'').toLowerCase();
  const has = (w)=> p.includes(w);
  if (g.includes('تخس') || g.includes('نقص') || g.includes('دايت')) {
    if (has('دجاج')) return sample('سلطة الدجاج المشوي','بروتين وخضار منخفض السعرات');
    if (has('بيض')) return sample('أومليت بالخضار','بروتين سريع التحضير');
    return sample('سلطة تونة خفيفة','بروتين ومذاق ممتع');
  }
  if (g.includes('عضل') || g.includes('زيادة')) {
    return sample('أرز ودجاج','طاقة وبروتين');
  }
  if (g.includes('سكري')) {
    return sample('شوربة عدس','ألياف وبروتين نباتي');
  }
  if (has('موز') || has('شوفان')) return sample('شوفان بالموز','ألياف وطاقة مستدامة');
  return sample('أرز بالخضار','وجبة متوازنة وسهلة');
}
function sample(title, reason) {
  return { title, reason, kcal: 350, time: '20 د', ingredients: [], steps: [] };
}
