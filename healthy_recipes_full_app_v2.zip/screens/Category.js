import React from 'react';
import { View, FlatList, TouchableOpacity, Image, Text } from 'react-native';
import data from '../seed';
import TopBar from '../components/TopBar';
export default function Category({ route, navigation }){
  const { id, name } = route.params || {};
  const items = data.filter(r=> r.cat===id);
  return (
    <View style={{flex:1, backgroundColor:'#fff'}}>
      <TopBar title={`📖 ${name||'القائمة'}`} onBack={()=>navigation.goBack()} />
      <FlatList data={items} keyExtractor={i=>i.id} contentContainerStyle={{padding:16, gap:12}}
        renderItem={({item})=>(
          <TouchableOpacity onPress={()=> navigation.navigate('Details',{id:item.id})}
            style={{flexDirection:'row', gap:12, borderWidth:1, borderColor:'#eee', borderRadius:16, padding:12}}>
            <Image source={{uri:item.image}} style={{width:80,height:80,borderRadius:12, backgroundColor:'#eee'}} />
            <View style={{flex:1}}>
              <Text style={{fontWeight:'700'}}>{item.title}</Text>
              <Text style={{color:'#666'}}>⏱ {item.time} • 🔥 {item.kcal}</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
