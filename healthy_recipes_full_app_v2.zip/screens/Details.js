import React from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import data from '../seed';
import TopBar from '../components/TopBar';
const KEY_FAVS = 'APP_FAVS_V1';
const KEY_NOTES = 'APP_NOTES_V1';
const KEY_LIST = 'APP_SHOP_V1';
export default function Details({ route, navigation }){
  const { id } = route.params || {};
  const rec = data.find(r=> r.id===id) || data[0];
  const [favs, setFavs] = React.useState([]);
  const [notes, setNotes] = React.useState('');
  React.useEffect(()=>{
    (async ()=>{
      const f = await AsyncStorage.getItem(KEY_FAVS); if(f) setFavs(JSON.parse(f));
      const n = await AsyncStorage.getItem(KEY_NOTES); if(n){ const obj=JSON.parse(n); setNotes(obj[id]||''); }
    })();
  },[]);
  React.useEffect(()=>{ AsyncStorage.setItem(KEY_FAVS, JSON.stringify(favs)); },[favs]);
  React.useEffect(()=>{ AsyncStorage.setItem(KEY_NOTES, JSON.stringify({[id]:notes})); },[notes]);
  const isFav = favs.includes(id);
  const toggleFav = ()=> setFavs(isFav? favs.filter(x=>x!==id) : [...favs, id]);
  const addToShop = async ()=>{
    const cur = JSON.parse(await AsyncStorage.getItem(KEY_LIST) || "[]");
    const merged = [...cur, ...rec.ingredients.map(x=>({ id: Date.now().toString()+Math.random(), text:x, done:false }))];
    await AsyncStorage.setItem(KEY_LIST, JSON.stringify(merged));
    Alert.alert('تم','أضيفت المكونات لقائمة التسوق');
  };
  return (
    <View style={{flex:1, backgroundColor:'#fff'}}>
      <TopBar title="تفاصيل الوصفة" onBack={()=>navigation.goBack()} />
      <ScrollView contentContainerStyle={{padding:16}}>
        <Image source={{uri:rec.image}} style={{height:220,borderRadius:16, backgroundColor:'#eee'}} />
        <Text style={{fontSize:22, fontWeight:'800', marginTop:8}}>{rec.title}</Text>
        <Text style={{color:'#666'}}>⏱ {rec.time} • 🔥 {rec.kcal}</Text>
        <Text style={{marginTop:12, fontWeight:'700'}}>المكونات</Text>
        {rec.ingredients.map((x,i)=><Text key={i}>• {x}</Text>)}
        <TouchableOpacity onPress={addToShop} style={{marginTop:8, backgroundColor:'#2e7d32', padding:12, borderRadius:12, alignItems:'center'}}>
          <Text style={{color:'#fff'}}>أضف المكونات إلى التسوق 🛒</Text>
        </TouchableOpacity>
        <Text style={{marginTop:12, fontWeight:'700'}}>الطريقة</Text>
        {rec.steps.map((x,i)=><Text key={i}>• {x}</Text>)}
        <View style={{flexDirection:'row', gap:8, marginTop:12}}>
          <TouchableOpacity onPress={toggleFav} style={{backgroundColor:isFav?'#9e9e9e':'#ff8a65', padding:12, borderRadius:12}}>
            <Text style={{color:'#fff'}}>{isFav?'إزالة من المفضلة':'أضف إلى المفضلة'} ❤️</Text>
          </TouchableOpacity>
        </View>
        <Text style={{marginTop:12, fontWeight:'700'}}>ملاحظاتك</Text>
        <TextInput value={notes} onChangeText={setNotes} multiline placeholder="اكتب ملاحظة..." style={{borderWidth:1,borderColor:'#ddd',borderRadius:12,padding:12, minHeight:80}}/>
      </ScrollView>
    </View>
  );
}
