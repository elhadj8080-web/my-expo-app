import React from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import TopBar from '../components/TopBar';
const KEY_LIST = 'APP_SHOP_V1';
export default function Shop({ navigation }){
  const [list, setList] = React.useState([]);
  const [t, setT] = React.useState('');
  React.useEffect(()=>{ (async()=>{ const s=await AsyncStorage.getItem(KEY_LIST); if(s) setList(JSON.parse(s)); })(); },[]);
  React.useEffect(()=>{ AsyncStorage.setItem(KEY_LIST, JSON.stringify(list)); },[list]);
  const add = ()=>{ if(!t.trim()) return; setList([...list, {id:Date.now().toString(), text:t.trim(), done:false}]); setT(''); };
  const toggle = (id)=> setList(list.map(i=> i.id===id? {...i, done:!i.done} : i));
  const remove = (id)=> setList(list.filter(i=> i.id!==id));
  const clearAll = ()=> setList([]);
  return (
    <View style={{flex:1, backgroundColor:'#fff'}}>
      <TopBar title="🛒 قائمة التسوق" onBack={()=>navigation.goBack()} />
      <View style={{padding:16}}>
        <View style={{flexDirection:'row', gap:8}}>
          <TextInput value={t} onChangeText={setT} placeholder="أضف عنصر..." style={{flex:1,borderWidth:1,borderColor:'#ddd',borderRadius:12,padding:12}}/>
          <TouchableOpacity onPress={add} style={{padding:12, backgroundColor:'#2e7d32', borderRadius:12}}><Text style={{color:'#fff'}}>إضافة</Text></TouchableOpacity>
        </View>
        <FlatList data={list} keyExtractor={i=>i.id} contentContainerStyle={{gap:8, marginTop:12}}
          renderItem={({item})=>(
            <View style={{flexDirection:'row', alignItems:'center', gap:8}}>
              <TouchableOpacity onPress={()=>toggle(item.id)} style={{width:22,height:22,borderRadius:6, borderWidth:2, borderColor:'#2e7d32', backgroundColor:item.done?'#2e7d32':'transparent'}}/>
              <Text style={[{flex:1}, item.done&&{textDecorationLine:'line-through', color:'#888'}]}>{item.text}</Text>
              <TouchableOpacity onPress={()=>remove(item.id)}><Text style={{color:'#e53935'}}>حذف</Text></TouchableOpacity>
            </View>
          )}/>
        <TouchableOpacity onPress={clearAll} style={{marginTop:8}}><Text style={{color:'#555'}}>تفريغ القائمة</Text></TouchableOpacity>
      </View>
    </View>
  );
}
