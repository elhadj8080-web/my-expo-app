import React from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList } from 'react-native';
import { useNavigation } from '@react-navigation/native';
const CATS = [
  { id:'breakfast', name:'إفطار', emoji:'🍳' },
  { id:'lunch', name:'غداء', emoji:'🥗' },
  { id:'dinner', name:'عشاء', emoji:'🍲' },
  { id:'snack', name:'سناك', emoji:'🥤' },
];
export default function Home(){ const nav = useNavigation(); const [q,setQ]=React.useState('');
  return (
    <View style={{flex:1, backgroundColor:'#fff', padding:16}}>
      <Text style={{fontSize:22, fontWeight:'800'}}>🍏 وصفات صحية</Text>
      <Text style={{color:'#666'}}>ابحث أو اختر تصنيف</Text>
      <TextInput placeholder="ابحث عن وصفة..." value={q} onChangeText={setQ}
        style={{marginTop:12, borderWidth:1, borderColor:'#ddd', borderRadius:12, padding:12}}/>
      <TouchableOpacity onPress={()=> nav.navigate('Search',{q})} style={{marginTop:8, backgroundColor:'#2e7d32', padding:12, borderRadius:12, alignItems:'center'}}>
        <Text style={{color:'#fff', fontWeight:'700'}}>بحث</Text>
      </TouchableOpacity>
      <Text style={{marginTop:16, fontWeight:'700'}}>التصنيفات</Text>
      <FlatList horizontal data={CATS} keyExtractor={i=>i.id} style={{marginTop:8}}
        contentContainerStyle={{gap:8}} showsHorizontalScrollIndicator={false}
        renderItem={({item})=>(
          <TouchableOpacity onPress={()=> nav.navigate('Category',{id:item.id, name:item.name})}
            style={{padding:16, backgroundColor:'#f1f8e9', borderRadius:16, marginRight:8}}>
            <Text style={{fontSize:18}}>{item.emoji} {item.name}</Text>
          </TouchableOpacity>
        )}/>
      <View style={{height:14}}/>
      <View style={{flexDirection:'row', flexWrap:'wrap', gap:8}}>
        <TouchableOpacity onPress={()=>nav.navigate('Favs')} style={{backgroundColor:'#e8f5e9', padding:12, borderRadius:12}}><Text>❤️ المفضلة</Text></TouchableOpacity>
        <TouchableOpacity onPress={()=>nav.navigate('Shop')} style={{backgroundColor:'#e8f5e9', padding:12, borderRadius:12}}><Text>🛒 التسوّق</Text></TouchableOpacity>
        <TouchableOpacity onPress={()=>nav.navigate('Add')} style={{backgroundColor:'#e8f5e9', padding:12, borderRadius:12}}><Text>➕ إضافة</Text></TouchableOpacity>
        <TouchableOpacity onPress={()=>nav.navigate('AI')} style={{backgroundColor:'#e8f5e9', padding:12, borderRadius:12}}><Text>🤖 مساعد</Text></TouchableOpacity>
      </View>
    </View>
  );
}
