import React from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import data from '../seed';
import TopBar from '../components/TopBar';
export default function Add({ navigation }){
  const [title,setTitle]=React.useState('');
  const [cat,setCat]=React.useState('breakfast');
  const [img,setImg]=React.useState('');
  const [kcal,setKcal]=React.useState('');
  const [time,setTime]=React.useState('');
  const [ings,setIngs]=React.useState('');
  const [steps,setSteps]=React.useState('');
  const save=()=>{
    const id='u_'+Date.now();
    const rec={ id, cat, title:title||'وصفة بدون اسم', image:img, kcal: Number(kcal)||0, time: time||'—',
      ingredients: ings.split(/[,،\n]+/).map(s=>s.trim()).filter(Boolean),
      steps: steps.split(/\n+/).map(s=>s.trim()).filter(Boolean)
    };
    data.unshift(rec);
    Alert.alert('تم','تمت إضافة الوصفة');
    navigation.goBack();
  };
  return (
    <View style={{flex:1, backgroundColor:'#fff'}}>
      <TopBar title="➕ إضافة وصفة" onBack={()=>navigation.goBack()} />
      <ScrollView contentContainerStyle={{padding:16}}>
        <Text>اسم الوصفة</Text>
        <TextInput value={title} onChangeText={setTitle} style={s.inp}/>
        <Text style={{marginTop:8}}>التصنيف (breakfast/lunch/dinner/snack)</Text>
        <TextInput value={cat} onChangeText={setCat} style={s.inp}/>
        <Text style={{marginTop:8}}>رابط صورة</Text>
        <TextInput value={img} onChangeText={setImg} style={s.inp}/>
        <Text style={{marginTop:8}}>سعرات حرارية</Text>
        <TextInput value={kcal} onChangeText={setKcal} keyboardType="numeric" style={s.inp}/>
        <Text style={{marginTop:8}}>الوقت</Text>
        <TextInput value={time} onChangeText={setTime} style={s.inp}/>
        <Text style={{marginTop:8}}>المكونات (افصل بينها بفواصل/أسطر)</Text>
        <TextInput value={ings} onChangeText={setIngs} style={[s.inp,{minHeight:80}]} multiline/>
        <Text style={{marginTop:8}}>الخطوات (سطر لكل خطوة)</Text>
        <TextInput value={steps} onChangeText={setSteps} style={[s.inp,{minHeight:100}]} multiline/>
        <TouchableOpacity onPress={save} style={{marginTop:12, backgroundColor:'#2e7d32', padding:12, borderRadius:12, alignItems:'center'}}>
          <Text style={{color:'#fff'}}>حفظ</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}
const s={ inp:{borderWidth:1,borderColor:'#ddd',borderRadius:12,padding:12, marginTop:4} };
