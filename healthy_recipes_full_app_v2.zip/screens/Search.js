import React from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, Image } from 'react-native';
import data from '../seed';
import TopBar from '../components/TopBar';
export default function Search({ route, navigation }){
  const [q, setQ] = React.useState(route.params?.q || '');
  const results = data.filter(r => (r.title + ' ' + r.ingredients.join(' ')).toLowerCase().includes(q.toLowerCase()));
  return (
    <View style={{flex:1, backgroundColor:'#fff'}}>
      <TopBar title="🔎 بحث" onBack={()=>navigation.goBack()} />
      <View style={{padding:16}}>
        <TextInput value={q} onChangeText={setQ} placeholder="ابحث..." style={{borderWidth:1,borderColor:'#ddd',borderRadius:12,padding:12}}/>
      </View>
      {q.trim().length===0 ? <Text style={{padding:16, color:'#666'}}>اكتب كلمات للبحث...</Text> :
        (results.length===0 ? <Text style={{padding:16}}>لا توجد نتائج</Text> :
          <FlatList data={results} keyExtractor={i=>i.id} contentContainerStyle={{padding:16, gap:12}}
            renderItem={({item})=>(
              <TouchableOpacity onPress={()=> navigation.navigate('Details',{id:item.id})}
                style={{flexDirection:'row', gap:12, borderWidth:1, borderColor:'#eee', borderRadius:16, padding:12}}>
                <Image source={{uri:item.image}} style={{width:80,height:80,borderRadius:12, backgroundColor:'#eee'}} />
                <View style={{flex:1}}>
                  <Text style={{fontWeight:'700'}}>{item.title}</Text>
                  <Text style={{color:'#666'}}>⏱ {item.time} • 🔥 {item.kcal}</Text>
                </View>
              </TouchableOpacity>
            )}/>)
      }
    </View>
  );
}
