import React from 'react';
import { View, Text, FlatList, TouchableOpacity, Image } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import data from '../seed';
import TopBar from '../components/TopBar';
const KEY_FAVS = 'APP_FAVS_V1';
export default function Favs({ navigation }){
  const [ids, setIds] = React.useState([]);
  React.useEffect(()=>{ (async()=>{ const f=await AsyncStorage.getItem(KEY_FAVS); if(f) setIds(JSON.parse(f)); })(); },[]);
  const favs = data.filter(d=> ids.includes(d.id));
  return (
    <View style={{flex:1, backgroundColor:'#fff'}}>
      <TopBar title="❤️ المفضلة" onBack={()=>navigation.goBack()} />
      {favs.length===0 ? <Text style={{padding:16, color:'#666'}}>لا شيء بعد.</Text> :
        <FlatList data={favs} keyExtractor={i=>i.id} contentContainerStyle={{padding:16, gap:12}}
          renderItem={({item})=>(
            <TouchableOpacity onPress={()=>navigation.navigate('Details',{id:item.id})}
              style={{flexDirection:'row', gap:12, borderWidth:1, borderColor:'#eee', borderRadius:16, padding:12}}>
              <Image source={{uri:item.image}} style={{width:80,height:80,borderRadius:12, backgroundColor:'#eee'}} />
              <View style={{flex:1}}>
                <Text style={{fontWeight:'700'}}>{item.title}</Text>
                <Text style={{color:'#666'}}>⏱ {item.time} • 🔥 {item.kcal}</Text>
              </View>
            </TouchableOpacity>
          )} />}
    </View>
  );
}
