import React from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { suggestRecipeByGoal } from '../utils/ai';
import TopBar from '../components/TopBar';
export default function AI({ navigation }){
  const [goal,setGoal]=React.useState('');
  const [pantry,setPantry]=React.useState('');
  const [res,setRes]=React.useState(null);
  const run=()=> setRes(suggestRecipeByGoal(goal, pantry));
  return (
    <View style={{flex:1, backgroundColor:'#fff'}}>
      <TopBar title="🤖 مساعد صحي (أوفلاين)" onBack={()=>navigation.goBack()} />
      <View style={{padding:16}}>
        <Text>هدفك الغذائي (مثال: خسارة وزن، زيادة عضل، سكري...)</Text>
        <TextInput value={goal} onChangeText={setGoal} style={s.inp} placeholder="اكتب هدفك..." />
        <Text style={{marginTop:8}}>ماذا لديك في المطبخ؟ (موز، بيض، دجاج ...)</Text>
        <TextInput value={pantry} onChangeText={setPantry} style={s.inp} placeholder="اكتب المكونات المتاحة..." />
        <TouchableOpacity onPress={run} style={{marginTop:12, backgroundColor:'#2e7d32', padding:12, borderRadius:12, alignItems:'center'}}>
          <Text style={{color:'#fff'}}>اقترح وصفة</Text>
        </TouchableOpacity>
        {res && <View style={{marginTop:16, padding:12, borderWidth:1, borderColor:'#eee', borderRadius:12}}>
          <Text style={{fontWeight:'700'}}>اقتراح: {res.title}</Text>
          <Text style={{color:'#666'}}>السبب: {res.reason}</Text>
          <Text>⏱ {res.time} • 🔥 {res.kcal}</Text>
        </View>}
      </View>
    </View>
  );
}
const s={ inp:{borderWidth:1,borderColor:'#ddd',borderRadius:12,padding:12, marginTop:4} };
